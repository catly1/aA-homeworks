class Bench < ApplicationRecord

  def self.in_bounds(bounds)
  end
end
