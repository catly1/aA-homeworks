export const allTodos = (state) => {
    // debugger
    return Object.keys(state.todos).map(id => state.todos[id])
}

window.allTodos = allTodos