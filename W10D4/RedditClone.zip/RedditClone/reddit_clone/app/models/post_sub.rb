class PostSub < ApplicationRecord
end
